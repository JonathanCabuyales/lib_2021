<?php

 // Configura path host
    define('HOST', 'http://localhost/libreria_2021');
       


