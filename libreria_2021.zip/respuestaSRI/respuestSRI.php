<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
// header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');

$dataPOST = $_POST['data'];

$jsonEncode = json_encode($dataPOST, true);
$dividir = explode(':', $dataPOST);

// $dividir = explode(';', $dataPOST);
echo json_encode(
    array(
        'longitud' => strlen($dataPOST),
        'estado' => $dividir[22],
        'fecha' => $dividir[30].$dividir[31].":".$dividir[32].":".$dividir[33],
        'numeroAutorizacion' => $dividir[26],
        'data' => $dividir,
        'dataPOST' => $dataPOST,
        'json' => $jsonEncode
    ),
    true
    );

/* echo json_encode(
    array(
        'data' => ($dataPOST),
        'sri' => $dataPOST['estado']
    ),
    true
); */